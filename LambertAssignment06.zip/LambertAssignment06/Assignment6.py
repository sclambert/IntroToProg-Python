'''
Created by:  Sophie Lambert
Date:  Aug 20, 2018
Course:  IT FDN 100 B - Assignment 6
Purpose: Create a program that reads info from .txt into a dictionary, then allows users to add,
remove, view, or save information to that dictionary. This program is very like the last one,
but this time you will place the code you created for working with your ToDo.txt file into Functions and a Class
'''

# -- Input/Output --#
#create a class to hold the list of functions
class ToDoClass(object):
    #define function
    dicTodo = {}

    def init(self):
        '''this function either creates or reads the ToDo.txt file and puts it in a dictionary'''
        # Case 1: file exists, skip next part
        # Case 2: file does not exists, do next part
        try:
            objfile = open("Todo.txt", "r")
            objfile.close()
        except:
            objfile = open("Todo.txt", "w")
            objfile.write("Clean House, low\nPay Bills, high")
            objfile = open("Todo.txt", "r")
            objfile.close()
        # Now read the data in the .txt and place it in a python dictionary
        objfile = open("Todo.txt", "r")
        fileinfo = objfile.readlines()
        objfile.close()
        for row in fileinfo:
            key, value = row.strip().split(", ")
            self.dicTodo[key] = (value)
        #put that dictionary into a list
        listTable = []
        for k, v in self.dicTodo.items():
            listTable += (k, v),

    def showlist(self):
        '''this function shows the users what's on the to do list'''
        # Step 3 -Show the current items in the table
        for k, v in self.dicTodo.items():
            print(k + ', ' + v)

    def additems(self):
        '''this function adds an item to the user's to do list'''
        UserWantsToAdd = True
        while (UserWantsToAdd):
            AddedTask = str(input("What task do you want to add? "))
            AddedPriority = str(input("What's its priority level? "))
            self.dicTodo[AddedTask] = AddedPriority
            strExit = input("\nType 'add' to add another task, otherwise type anything else to return to menu")
            if (strExit == 'add'):
                UserWantToAdd = True
            else:
                UserWantsToAdd = False

    def removeitems(self):
        '''this function removes an item from the user's to do list'''
        UserWantsToRemove = True
        while (UserWantsToRemove):
            RemovedTask = str(input("Which task do you want to remove?"))
            if RemovedTask in self.dicTodo:
                del self.dicTodo[RemovedTask]
                print(RemovedTask + " has been removed")
            elif RemovedTask not in self.dicTodo:
                print("That task is not on the list")
            strExit = input("\nType 'remove' to remove another task, otherwise type anything else to return to menu")
            if (strExit == 'remove'):
                UserWantsToRemove = True
            else:
                UserWantsToRemove = False

    def savedata(self):
        '''this function saves the user's to do list to the .txt file '''
        objfile = open("Todo.txt", "w")
        for k, v in self.dicTodo.items():
            objfile.write(k + ', ' + v + '\n')
        objfile.close()
        print("Your work has been saved")

#-- Processing --#
ToDoObj = ToDoClass()
ToDoObj.init()

while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line
    if strChoice.strip() == '1':
        ToDoObj.showlist()
    elif strChoice.strip() == '2':
        ToDoObj.additems()
    elif strChoice.strip() == '3':
        ToDoObj.removeitems()
    elif strChoice.strip() == '4':
        ToDoObj.savedata()
    elif strChoice.strip() == '5':
        print("Goodbye!")
        break




