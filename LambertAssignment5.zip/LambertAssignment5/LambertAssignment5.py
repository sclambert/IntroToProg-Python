'''
Created by:  Sophie Lambert
Date:  Aug 13, 2018
Course:  IT FDN 100 B - Assignment 5
Purpose: Create a program that reads info from .txt into a dictionary, then allows users to add,
remove, view, or save information to that dictionary
'''


# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------




#1 Create file and fill it with example data
#case 1: file exists, skip next part
#case 2: file does not exists, do next part
try:
    objfile = open("Todo.txt", "r")
    objfile.close()
except:
    objfile = open("Todo.txt", "w")
    objfile.write("Clean House, low\nPay Bills, high")
    objfile = open("Todo.txt", "r")
    objfile.close()

#2. At program start, load each row of data from the ToDo.txt text file into a Python dictionary.
dicTodo = {}
objfile = open("Todo.txt", "r")
fileinfo = objfile.readlines()
objfile.close()
for row in fileinfo:
    key,value = row.strip().split(", ")
    dicTodo[key] = (value)

#3.	After you get the data in a Python dictionary, Add the new dictionary “row”
# into a Python list object (now the data will be managed as a table).
listTable = []
for k, v in dicTodo.items():
    listTable += (k, v),

#Here's the meat of the actual code
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        for k, v in dicTodo.items():
            print(k+', '+ v)
        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        UserWantsToAdd = True
        while (UserWantsToAdd):
            AddedTask = str(input("What task do you want to add? "))
            AddedPriority = str(input("What's its priority level? "))
            dicTodo[AddedTask] = AddedPriority
            strExit = input("\nType 'add' to add another task, otherwise type anything else to return to menu")
            if (strExit == 'add'):
                UserWantToAdd = True
            else:
                UserWantsToAdd = False

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        UserWantsToRemove = True
        while (UserWantsToRemove):
            RemovedTask = str(input("Which task do you want to remove?"))
            if RemovedTask in dicTodo:
                del dicTodo[RemovedTask]
                print(RemovedTask + " has been removed")
            elif RemovedTask not in dicTodo:
                print("That task is not on the list")
            strExit = input("\nType 'remove' to remove another task, otherwise type anything else to return to menu")
            if (strExit == 'remove'):
                UserWantsToRemove = True
            else:
                UserWantsToRemove = False

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        objfile = open("Todo.txt", "w")
        for k, v in dicTodo.items():
            objfile.write(k + ', ' + v + '\n')
        objfile.close()
        print("Your work has been saved")
        continue

    elif (strChoice == '5'):
        break  # and Exit the program



